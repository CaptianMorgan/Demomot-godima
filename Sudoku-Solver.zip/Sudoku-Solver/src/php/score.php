<?php
/**
 * Created by PhpStorm.
 * User: godima
 * Date: 12.06.2017
 * Time: 08:48
 */
include ("classes/DB.php");
$db = new DB();
$scores = $db->getAllScoreOrderByValue();
?>
<div class="mui-container mui--text-center">
<table class="mui-table">
    <thead>
    <tr>
        <th>Temps</th>
        <th>Difficulté</th>
        <th>Joueur</th>
    </tr>
    </thead>
    <tbody>
<?php
foreach($scores as $score)
{
    ?>
    <tr>
        <td><?php echo $score['scoValue'] ?></td>
        <td><?php echo $score['scoDifficulty'] ?></td>
        <td><?php echo $score['usePseudo'] ?></td>
    </tr>

<?php
}
?>
</tbody>
</table>
</div>
